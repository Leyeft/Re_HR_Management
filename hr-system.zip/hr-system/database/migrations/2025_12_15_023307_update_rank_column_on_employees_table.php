<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */

    public function up(): void
{
    Schema::table('employees', function (Blueprint $table) {
        $table->enum('rank', ['employee', 'head', 'manager'])
              ->default('employee')
              ->change();
    });
}

public function down(): void
{
    Schema::table('employees', function (Blueprint $table) {
        $table->string('rank')->change();
    });
}

};
