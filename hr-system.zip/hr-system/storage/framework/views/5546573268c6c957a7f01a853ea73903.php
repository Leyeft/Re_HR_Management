<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800">
            Request Leave
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8 max-w-xl mx-auto">
        <div class="bg-white shadow rounded-lg p-6">

            <form method="POST" action="<?php echo e(route('leave.store')); ?>">
                <?php echo csrf_field(); ?>

                <div>
                    <label class="block text-sm font-medium">Start Date</label>
                    <input type="date" name="start_date"
                           class="w-full border rounded mt-1 p-2"
                           required>
                </div>

                <div class="mt-4">
                    <label class="block text-sm font-medium">End Date</label>
                    <input type="date" name="end_date"
                           class="w-full border rounded mt-1 p-2"
                           required>
                </div>

                <div class="mt-4">
                    <label class="block text-sm font-medium">Reason</label>
                    <textarea name="reason"
                              rows="4"
                              class="w-full border rounded mt-1 p-2"
                              required></textarea>
                </div>

                <div class="flex justify-end mt-6">
                    <button class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
                        Submit Request
                    </button>
                </div>

            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\HR_Management\HR-Management-System\hr-system\resources\views/leave/create.blade.php ENDPATH**/ ?>