<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800">
            Edit Employee
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8 max-w-4xl mx-auto">
        <div class="bg-white shadow rounded-lg p-6">

            <form method="POST" action="<?php echo e(route('employees.update', $employee->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-4">
                    <label class="block text-sm font-medium">Name</label>
                    <input type="text"
                           name="name"
                           class="w-full border rounded p-2 mt-1"
                           value="<?php echo e(old('name', $employee->user->name)); ?>"
                           required>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium">Email</label>
                    <input type="email"
                           name="email"
                           class="w-full border rounded p-2 mt-1"
                           value="<?php echo e(old('email', $employee->user->email)); ?>"
                           required>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium">Date of Birth</label>
                    <input type="date"
                           name="date_of_birth"
                           class="w-full border rounded p-2 mt-1"
                           value="<?php echo e(old('date_of_birth', $employee->date_of_birth)); ?>"
                           required>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium">Department</label>
                    <select name="department_id" class="w-full border rounded p-2 mt-1">
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($department->id); ?>"
                                <?php echo e($employee->department_id == $department->id ? 'selected' : ''); ?>>
                                <?php echo e($department->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-6">
                    <label class="block text-sm font-medium">Rank</label>
                    <select name="rank" class="w-full border rounded p-2 mt-1">
                        <option value="employee" <?php echo e($employee->rank === 'employee' ? 'selected' : ''); ?>>
                            Employee
                        </option>
                        <option value="head" <?php echo e($employee->rank === 'head' ? 'selected' : ''); ?>>
                            Head of Department
                        </option>
                    </select>
                </div>

                <div class="flex justify-end">
                    <button class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
                        Update Employee
                    </button>
                </div>

            </form>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\HR_Management\HR-Management-System\hr-system\resources\views/employees/edit.blade.php ENDPATH**/ ?>