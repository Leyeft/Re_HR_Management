<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200">
            Create Department
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6 max-w-xl mx-auto">
        <form method="POST" action="<?php echo e(route('departments.store')); ?>">
            <?php echo csrf_field(); ?>

            
            <div>
                <label class="block">Department Name</label>
                <input
                    type="text"
                    name="name"
                    class="w-full border p-2 mt-1"
                    value="<?php echo e(old('name')); ?>"
                    required
                >
            </div>

            
            <div class="mt-4">
                <label class="block">Description (Optional)</label>
                <textarea
                    name="description"
                    class="w-full border p-2 mt-1"
                    rows="3"
                ><?php echo e(old('description')); ?></textarea>
            </div>

            <button class="mt-4 bg-green-600 text-black px-4 py-2 rounded">
                Save
            </button>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\HR_Management\HR-Management-System\hr-system\resources\views/departments/create.blade.php ENDPATH**/ ?>