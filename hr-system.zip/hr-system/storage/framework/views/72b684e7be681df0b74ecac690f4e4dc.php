<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800">
            My Leave Requests
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8 max-w-6xl mx-auto">

        <div class="flex justify-end mb-4">
            <a href="<?php echo e(route('leave.create')); ?>"
               class="bg-indigo-600 text-white px-4 py-2 rounded">
                + Request Leave
            </a>
        </div>

        <div class="bg-white shadow rounded-lg overflow-hidden">
            <table class="w-full">
                <thead class="bg-gray-100 text-left text-sm">
                    <tr>
                        <th class="p-3">Dates</th>
                        <th class="p-3">Reason</th>
                        <th class="p-3">Status</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="border-t">
                            <td class="p-3">
                                <?php echo e($leave->start_date); ?> → <?php echo e($leave->end_date); ?>

                            </td>

                            <td class="p-3">
                                <?php echo e($leave->reason); ?>

                            </td>

                            <td class="p-3">
                                <?php if($leave->status === 'pending'): ?>
                                    <span class="px-2 py-1 text-xs bg-yellow-100 text-yellow-700 rounded">
                                        Pending
                                    </span>

                                <?php elseif($leave->status === 'approved'): ?>
                                    <span class="px-2 py-1 text-xs bg-green-100 text-green-700 rounded">
                                        Approved
                                    </span>

                                <?php else: ?>
                                    <span class="px-2 py-1 text-xs bg-red-100 text-red-700 rounded">
                                        Rejected
                                    </span>

                                    <?php if($leave->rejection_reason): ?>
                                        <div class="text-xs text-gray-500 mt-1">
                                            Reason: <?php echo e($leave->rejection_reason); ?>

                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="3" class="p-6 text-center text-gray-500">
                                No leave requests yet.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-4">
            <?php echo e($leaves->links()); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\HR_Management\HR-Management-System\hr-system\resources\views/leave/index.blade.php ENDPATH**/ ?>