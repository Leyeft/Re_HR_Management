<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800">
            Dashboard
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8 max-w-7xl mx-auto space-y-6">

        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="bg-white p-6 rounded shadow">
                <h3 class="text-sm text-gray-500">Total Staff</h3>
                <p class="text-3xl font-bold"><?php echo e($totalStaff); ?></p>
            </div>

            <div class="bg-white p-6 rounded shadow">
                <h3 class="text-sm text-gray-500">Total Departments</h3>
                <p class="text-3xl font-bold"><?php echo e($totalDepartments); ?></p>
            </div>
        </div>

        
        <div class="bg-white p-6 rounded shadow">
            <h3 class="text-lg font-semibold mb-4">
                Staff by Department
            </h3>

            <div class="max-w-md mx-auto">
                <canvas id="departmentChart"></canvas>
            </div>
        </div>

        
        <<div class="mt-8 bg-white p-6 rounded shadow">
            <h3 class="text-lg font-semibold mb-4">
                Leave Request Status
            </h3>

            <div class="max-w-md mx-auto">
                <canvas id="leaveStatusChart"></canvas>
        </div>
</div>


    </div>

    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script>
        // PIE CHART
        const deptCtx = document.getElementById('departmentChart');

        new Chart(deptCtx, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode($labels, 15, 512) ?>,
                datasets: [{
                    data: <?php echo json_encode($data, 15, 512) ?>,
                    backgroundColor: [
                        '#4f46e5',
                        '#22c55e',
                        '#f97316',
                        '#ef4444',
                        '#14b8a6',
                        '#eab308',
                    ],
                }]
            }
        });

        // BAR CHART
        const leaveCtx = document.getElementById('leaveStatusChart');

        new Chart(leaveCtx, {
            type: 'bar',
            data: {
                labels: ['Pending', 'Approved', 'Rejected'],
                datasets: [{
                    label: 'Leave Requests',
                    data: [
                        <?php echo e($leaveStats['pending']); ?>,
                        <?php echo e($leaveStats['approved']); ?>,
                        <?php echo e($leaveStats['rejected']); ?>

                    ],
                    backgroundColor: [
                        '#FACC15',
                        '#22C55E',
                        '#EF4444'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: { stepSize: 1 }
                    }
                }
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\HR_Management\HR-Management-System\hr-system\resources\views/dashboard.blade.php ENDPATH**/ ?>