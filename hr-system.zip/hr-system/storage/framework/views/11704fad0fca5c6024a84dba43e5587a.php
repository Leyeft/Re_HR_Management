<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold">Leave Approvals</h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6 max-w-7xl mx-auto">

        <?php if(session('success')): ?>
            <div class="mb-4 p-3 bg-green-100 text-green-700 rounded">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="bg-white shadow rounded">
            <table class="w-full">
                <thead class="bg-gray-100 text-sm">
                    <tr>
                        <th class="p-3 text-left">Employee</th>
                        <th class="p-3">Dates</th>
                        <th class="p-3">Reason</th>
                        <th class="p-3 text-right">Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="border-t">
                            <td class="p-3">
                                <?php echo e($leave->employee->user->name); ?>

                            </td>
                            <td class="p-3">
                                <?php echo e($leave->start_date); ?> → <?php echo e($leave->end_date); ?>

                            </td>
                            <td class="p-3">
                                <?php echo e($leave->reason); ?>

                            </td>
                            <td class="p-3 text-right space-x-2">
                                <form method="POST" action="<?php echo e(route('leave.approve', $leave)); ?>" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <button class="bg-green-600 text-white px-3 py-1 rounded text-sm">
                                        Approve
                                    </button>
                                </form>

                                <form method="POST" action="<?php echo e(route('leave.reject', $leave)); ?>" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <input type="text"
                                           name="rejection_reason"
                                           placeholder="Reject reason"
                                           required
                                           class="border rounded px-2 py-1 text-sm">
                                    <button class="bg-red-600 text-white px-3 py-1 rounded text-sm">
                                        Reject
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="p-6 text-center text-gray-500">
                                No pending requests.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-4">
            <?php echo e($requests->links()); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\HR_Management\HR-Management-System\hr-system\resources\views/leave-approvals/index.blade.php ENDPATH**/ ?>